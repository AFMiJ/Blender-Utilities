# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
 
bl_info = {
    "name": "AFM gsf mesh",
    "author": "original author: zeffii stanton, gsf version: Lorenzo AFMiJ.eu",
    "version": (0,4),
    "blender": (3, 1, 2),
    "location": "File > Import > AFM gsf",
    "description": "Import AFM data from files (.gsf format)",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Import-Export"}

if "bpy" in locals():
    import imp
    if "import_afm_gsf" in locals():
        imp.reload(import_afm_gsf)
else:
    import bpy

from bpy.props import StringProperty, FloatProperty


class AFMImporter(bpy.types.Operator):
    """Load AFM triangle mesh data"""
    bl_idname = "import_afm_gsf.txt"
    bl_label = "Import AFM gsf data"

    filepath : StringProperty(   name="File Path",
                                 description="Filepath used for importing the AFM file",
                                 maxlen=1024, default="", subtype='FILE_PATH')

    filter_glob : StringProperty(default="*.gsf", options={'HIDDEN'})

    Z_factor : FloatProperty(name="Z expansion factor", default=3, min=0.1, max=20)

    def execute(self, context):
        from . import import_afm_gsf
        import_afm_gsf.startgsfimport(self.filepath,self.Z_factor)
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        wm.fileselect_add(self)
        return {'RUNNING_MODAL'}


def menu_func(self, context):
    self.layout.operator(AFMImporter.bl_idname, text="AFM data (.gsf)")

def register():
    bpy.utils.register_class(AFMImporter)
    bpy.types.TOPBAR_MT_file_import.append(menu_func)

def unregister():
    bpy.utils.unregister_class(AFMImporter)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func)

if __name__ == "__main__":
    register()
