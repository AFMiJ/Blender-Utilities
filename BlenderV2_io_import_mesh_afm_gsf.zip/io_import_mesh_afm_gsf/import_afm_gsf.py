# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


import bpy
import struct

# Constants

WORLD_SCALING = 0.01 # Lorenzo

# Lorenzo ^^ NOW WORKS WITH RECTANGULAR MATRICES ^^^
def CreateMeshUsingMatrix(VertIndices, Verts, NX,NY):

    Faces = []

    # going to use current row and next row all the way down
    for row in range(NY-1):
        #now take row and row+1
        for col in range(NX-1):
            #we generate faces clockwise from 4 Verts
            val1 = VertIndices[row][col]
            val2 = VertIndices[row][col+1]
            val3 = VertIndices[row+1][col+1]
            val4 = VertIndices[row+1][col]
            face = [val1, val2, val3, val4]
            Faces.append(face)

    ## TAKEN FROM USER    ValterVB 
    # create new mesh structure
    mesh = bpy.data.meshes.new("Relief")
    mesh.from_pydata(Verts, [], Faces)
    mesh.update()
    new_object = bpy.data.objects.new("AFM gsf Data", mesh)
    new_object.data = mesh
    scene = bpy.context.scene
    scene.objects.link(new_object)
    scene.objects.active = new_object
    new_object.select = True
    ## / TAKEN FROM USER


# Deals with opening the file and taking data.
# Lorenzo start
# compatibility up to gsf file format 1.0
def startgsfimport(filename,Z_FACTOR):
    offset=0                # default data chunk offset
    file=""                 
    VertIndices = []
    xyunits="nm"            # all units are nm now
    zunits="nm"             # all units are nm now
    xyscale = 1
    zscale = 1

    #print("\n====================\n")

    f = open(filename,'rb')
    dummy=str(f.read(2048))
    #print("dummy start\n")
    #print(dummy)
    #print("dummy end\n")
    header=dummy.split("\\x00")[0]
    #headerlength = len(header)-2
    #print(header,"\n ===== header end ====")
    #print(headerlength,"\n")
    lines = header.split("\\n")
    cleanheader = header.replace("\\n","\\")
    headerlength = len(cleanheader)-2
    #print("clean header length",headerlength,"\n")
    offset = headerlength + 4 - headerlength % 4
    #print ("clean offset=",offset,"\n")
    for line in lines:
        #print(line,"\n")
        label = line.split("=")[0].strip()
        #print (label,"\n----")
        if len(line.split("=")) == 2:
            svalue = line.split("=")[1].strip()
            #value = float(svalue)
            if label=="XRes":
                NX= int(svalue)
                #print (NX,"\n")
            if label=="YRes":
                NY = int(svalue)
            if label=="XReal":
                DELTAX = float(svalue)
            if label=="YReal":
                DELTAY = float(svalue)
            if label=="XYUnits":
                xyunits = svalue
            if label=="ZUnits":
                zunits = svalue

    if xyunits=="m":
        xyscale = 1e9
    if zunits=="m":
        zscale = 1e9
    DELTA_X=DELTAX/NX
    DELTA_Y=DELTAY/NY
    f.close()
    heightMatrix = [[0 for x in range(NX)] for y in range(NY)] # define the matrix
    f = open(filename, 'rb')
    dummy=f.read(offset)      # skipping to the data chunk
    for rows in range(NY):    # filling the matrix with data
        for cols in range(NX):
            byte=f.read(4)
            value=struct.unpack('f', byte)
            heightMatrix [rows][cols]=value[0]*Z_FACTOR*WORLD_SCALING*zscale
            #print(cols,rows,value[0]*Z_FACTOR*WORLD_SCALING*zscale,heightMatrix [rows][cols])
    f.close()
# Lorenzo end

    # preparing the matrix for the mesh computation.
    x_val = []
    for i in range(NX): x_val.append(i*WORLD_SCALING*DELTA_X*xyscale)
    y_val = []
    for j in range(NY): y_val.append(j*WORLD_SCALING*DELTA_Y*xyscale)

    # Generates the (x,y,height) matrix, no need for Vector(...) 
    yVal = 0
    vertNum = 0
    rawVertCollection = []
    for height_x in heightMatrix:
        xVal = 0
        vertRow = []
        for item in height_x:
            t_vertice = (x_val[xVal], -y_val[yVal], heightMatrix[yVal][xVal])
            rawVertCollection.append(t_vertice)
            vertRow.append(vertNum)
            xVal+=1
            vertNum+=1
        yVal+=1
        VertIndices.append(vertRow)

    # done here, lets make a mesh! 
    CreateMeshUsingMatrix(VertIndices, rawVertCollection,NX,NY)

# package manages registering
