# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


import bpy
import struct

# Constants
WORLD_SCALING = 0.01    # Lorenzo
xunit="nm"              # Lorenzo all units are nm now
yunit="nm"              # Lorenzo all units are nm now
zunit="nm"              # Lorenzo all units are nm now



# Lorenzo ^^ NOW WORKS WITH RECTANGULAR MATRICES ^^^
def CreateMeshUsingMatrix(VertIndices, Verts, NX,NY):

    Faces = []

    # going to use current row and next row all the way down
    for row in range(NY-1):
        #now take row and row+1
        for col in range(NX-1):
            #we generate faces clockwise from 4 Verts
            val1 = VertIndices[row][col]
            val2 = VertIndices[row][col+1]
            val3 = VertIndices[row+1][col+1]
            val4 = VertIndices[row+1][col]
            face = [val1, val2, val3, val4]
            Faces.append(face)

    ## TAKEN FROM USER    ValterVB 
    # create new mesh structure
    mesh = bpy.data.meshes.new("Relief")
    mesh.from_pydata(Verts, [], Faces)
    mesh.update()
    new_object = bpy.data.objects.new("AFM bcrf Data", mesh)
    new_object.data = mesh
    scene = bpy.context.scene
    scene.objects.link(new_object)
    scene.objects.active = new_object
    new_object.select = True
    ## / TAKEN FROM USER


# Deals with opening the file and taking data.
#  Lorenzo start
# compatibility up to SPIP 4.2
def startbcrfimport(filename,Z_FACTOR):
    offset=0                # default data chunk offset
    file=""                 
    VertIndices = []

    f = open(filename, 'rb')
    dummy0=str(f.read(1024))
    dummy=dummy0.replace("\\x00","")
    metadata=dummy.split("\\n")  # this part could be improved 
    fileformat=metadata[0]
    fileformat=fileformat[2:]
    
    if fileformat == "fileformat = bcrf":
           offset=2048-1024
           file="OK"

    if fileformat == "fileformat = bcrf_unicode":
           offset=4096-1024
           file="OK"
           
    if file != "OK":
         return "not a valid bcrf file"

    for m in metadata:
        #print (m)
        if len(m)>0:
           chunks=m.split()
           if chunks[0] == "xpixels":
              NX=int(chunks[2])
           if chunks[0] == "ypixels": 
              NY=int(chunks[2])
           if chunks[0] == "xlength":
              DELTAX=float(chunks[2])
              DELTA_X=DELTAX/NX
           if chunks[0] == "ylength":
              DELTAY=float(chunks[2])
              DELTA_Y=DELTAY/NY
           if chunks[0] == "xunit":
              xunit=chunks[2]
           if chunks[0] == "yunit":
              yunit=chunks[2]
           if chunks[0] == "zunit":
              zunit=chunks[2]
# I should really add some code to deal with NON nm units

    heightMatrix = [[0 for x in range(NX)] for y in range(NY)] # define the matrix

    dummy=f.read(offset)      # skipping to the data chunk
    for rows in range(NY):    # filling the matrix with data
        for cols in range(NX):
            byte=f.read(4)
            value=struct.unpack('f', byte)
            heightMatrix [rows][cols]=value[0]*Z_FACTOR*WORLD_SCALING
            #print(cols,rows,value[0]*Z_FACTOR*WORLD_SCALING,heightMatrix [rows][cols])
    f.close()
    #print ("File closed, Deltax and NX are:", DELTAX,NX)
    #print ("File closed, Delta_X is:", DELTA_X)
   
    # preparing the matrix for the mesh computation.
    x_val = []
    for i in range(NX): x_val.append(i*WORLD_SCALING*DELTA_X)
    y_val = []
    for j in range(NY): y_val.append(j*WORLD_SCALING*DELTA_Y)
# Lorenzo END

    # Generates the (x,y,height) matrix, no need for Vector(...) 
    yVal = 0
    vertNum = 0
    rawVertCollection = []
    for height_x in heightMatrix:
        xVal = 0
        vertRow = []
        for item in height_x:
            t_vertice = (x_val[xVal], -y_val[yVal], heightMatrix[yVal][xVal]) # LOR
            rawVertCollection.append(t_vertice)
            vertRow.append(vertNum)
            xVal+=1
            vertNum+=1
        yVal+=1
        VertIndices.append(vertRow)

    # done here, lets make a mesh! 
    CreateMeshUsingMatrix(VertIndices, rawVertCollection,NX,NY)

# package manages registering
